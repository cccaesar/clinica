package com.example.clinica.dtos;
/**
 *
 * @author caio
 */
public record PacienteUpdateRecordDto(String nome, String telefone, EnderecoUpdateRecordDto endereco) {

}
