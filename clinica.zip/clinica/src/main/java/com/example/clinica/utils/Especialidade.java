package com.example.clinica.utils;

/**
 *
 * @author caio
 */
public enum Especialidade {
    ORTOPEDIA,
    CARDIOLOGIA,
    GINECOLOGIA,
    DERMATOLOGIA
}
